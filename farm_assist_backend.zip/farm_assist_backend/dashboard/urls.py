# dashboard/urls.py

from django.urls import path
from .views import SoilConditionListCreateView

urlpatterns = [
    path('soil/', SoilConditionListCreateView.as_view(), name='soil_conditions'),
    # Add more URL patterns here as needed
]
