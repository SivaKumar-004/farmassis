# dashboard/views.py

from rest_framework import generics, permissions
from .models import SoilCondition
from .serializers import SoilConditionSerializer

class SoilConditionListCreateView(generics.ListCreateAPIView):
    queryset = SoilCondition.objects.all()
    serializer_class = SoilConditionSerializer
    permission_classes = [permissions.IsAuthenticated]
from django.shortcuts import render

# Create your views here.
