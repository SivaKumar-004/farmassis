# dashboard/serializers.py

from rest_framework import serializers
from .models import SoilCondition

class SoilConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = SoilCondition
        fields = '__all__'
