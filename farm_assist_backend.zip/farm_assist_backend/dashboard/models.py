# dashboard/models.py

from django.db import models
from accounts.models import FarmerProfile  # Ensure correct import based on your accounts app

class SoilCondition(models.Model):
    farmer = models.ForeignKey(FarmerProfile, on_delete=models.CASCADE)
    moisture_level = models.FloatField()
    fertility_level = models.FloatField()
    recorded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.farmer.user.username} - {self.recorded_at.strftime('%Y-%m-%d %H:%M')}"
from django.db import models

# Create your models here.
