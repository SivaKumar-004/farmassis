# dashboard/admin.py

from django.contrib import admin
from .models import SoilCondition

admin.site.register(SoilCondition)
from django.contrib import admin

# Register your models here.
