
# crops/urls.py

from django.urls import path
from .views import CropListView

urlpatterns = [
    path('', CropListView.as_view(), name='crop_list'),
]
