from django.db import models

# Create your models here.
# crops/models.py

from django.db import models

class Crop(models.Model):
    name = models.CharField(max_length=100)
    optimal_temperature = models.FloatField()
    optimal_soil_fertility = models.FloatField()
    fertilizer_recommendation = models.CharField(max_length=200)

    def __str__(self):
        return self.name
