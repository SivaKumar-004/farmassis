# crops/views.py

from rest_framework import generics, permissions
from .models import Crop
from .serializers import CropSerializer

class CropListView(generics.ListAPIView):
    queryset = Crop.objects.all()
    serializer_class = CropSerializer
    permission_classes = [permissions.IsAuthenticated]
