# crops/admin.py

from django.contrib import admin
from .models import Crop

admin.site.register(Crop)
from django.contrib import admin

# Register your models here.
