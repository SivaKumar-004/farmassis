from django.contrib import admin

# Register your models here.
# accounts/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, FarmerProfile

class CustomUserAdmin(UserAdmin):
    model = User
    list_display = ['username', 'email', 'is_farmer', 'is_house']

admin.site.register(User, CustomUserAdmin)
admin.site.register(FarmerProfile)